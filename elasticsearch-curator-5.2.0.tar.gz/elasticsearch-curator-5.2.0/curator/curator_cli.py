import click
from .singletons import cli

def main():
    cli(obj={})
